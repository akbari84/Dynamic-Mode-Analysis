function ExtractPerturbations()
clc;

%% Path string parameters
index=1;

%% Path strings
% Replace WorkingDirectory with your working directory in all the file paths.
strDataPath='WorkingDirectory\Glycolysis\Shared-data';
strReadFileEXL1=strcat(strDataPath,'\EXL\C0_Perts-',num2str(index),'.csv');
strSaveFileMAT=strcat(strDataPath,'\MAT\C0_Perts-',num2str(index),'.mat');

%% Parameters
i_nad=13;
N_tot=0.089;

%% Read perturbations
% Read data sheets
data=readmatrix(strReadFileEXL1);

% Extract parameters
[n_sample,mm]=size(data);
C0_data=[data(:,2:i_nad),zeros(n_sample,1),data(:,i_nad+1:mm)];

%% Fill NAD concentrations
for i=1:n_sample
    C0_data(i,i_nad)=N_tot-C0_data(i,i_nad+1);
end

%% Save data
save(strSaveFileMAT,'C0_data','n_sample');

return
