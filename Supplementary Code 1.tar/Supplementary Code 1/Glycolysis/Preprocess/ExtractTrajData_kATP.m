function ExtractTrajData_kATP()
clc;

%% Path string parameters
index=2;

%% Path strings
% Replace WorkingDirectory with your working directory in all the file paths.
strDataPath='WorkingDirectory\Glycolysis\Shared-data';
strReadFileEXL1=strcat(strDataPath,'\EXL\kATP_concentrations-',num2str(index),'.csv');
strReadFileEXL2=strcat(strDataPath,'\EXL\kATP_concentrations_ss-',num2str(index),'.csv');
strSaveFileMAT=strcat(strDataPath,'\MAT\kATP_concentrations-',num2str(index),'.mat');

%% Read data sheets
data1=readmatrix(strReadFileEXL1);
data2=readmatrix(strReadFileEXL2);

%% Parameters
n_sample=1;

%% Memory allocations
spl=cell(n_sample,1);

%% Extract parameters
[n_tp,mm1]=size(data1);
mm2=size(data2,2);
spl{1}.C_data=data1(:,2:mm1);
spl{1}.t_data=data1(:,1);
spl{1}.n_tp=n_tp;
Css_data=data2(1,2:mm2);

%% Save data
save(strSaveFileMAT,'spl','n_sample','Css_data');

return
