function ExtractParameters()
clc;

%% Path string parameters
index=2;

%% Path strings
% Replace WorkingDirectory with your working directory in all the file paths.
strDataPath='WorkingDirectory\Glycolysis\Shared-data';
strReadFileEXL=strcat(strDataPath,'\EXL\parameters-',num2str(index),'.xlsx');
strSaveFileMAT=strcat(strDataPath,'\MAT\parameters-',num2str(index),'.mat');

%% Read data sheets
data_S=readcell(strReadFileEXL,'Sheet','S');
data_Therm=readcell(strReadFileEXL,'Sheet','Therm');
data_Kin=readcell(strReadFileEXL,'Sheet','Kin');

%% Extract parameters
[nn,mm]=size(data_S);
n_met=nn-1;
n_rxn=mm-1;
met_names=data_S(2:nn,1);
rxn_names=data_Therm(2:mm,1);
S=cell2mat(data_S(2:nn,2:mm));
Keq=cell2mat(data_Therm(2:mm,2));
Gamma_Keq=cell2mat(data_Therm(2:mm,3));
k_perc=cell2mat(data_Kin(2:mm,2));
v_exp=cell2mat(data_Kin(2:mm,3));

%% Save data
save(strSaveFileMAT,'met_names','rxn_names','S','Keq','Gamma_Keq','k_perc','v_exp','n_met','n_rxn');

return