function SpectrumFromTraj_ODMD_v3()
% Minimization is performed using a Dynamic Mode Decomposition method 
% Version 3: w and F are estimated by exactly solving an optimization problem.
clc;

%% Parameters to set up path strings 
index=2;

%% Path strings
% Replace WorkingDirectory with your working directory in all the file paths.
strPlotPath='WorkingDirectory\Glycolysis\Plots\kATP';
strDataPath='WorkingDirectory\Glycolysis\Shared-data';
strReadFileMAT1=strcat(strDataPath,'\MAT\kATP_concentrations-',num2str(index),'.mat');
strReadFileMAT2=strcat(strDataPath,'\MAT\parameters-',num2str(index),'.mat');
strPlotFilePDF1=strcat(strPlotPath,'\ConcProfile_PoolDim_COV-',num2str(index),'.pdf');
strPlotFilePDF2=strcat(strPlotPath,'\ConcProfile_PoolDim_ODMD-',num2str(index),'.pdf');
strPlotFilePDF3=strcat(strPlotPath,'\DominantEigV_PoolDim_ODMD-',num2str(index),'.pdf');
strPlotFilePDF4=strcat(strPlotPath,'\Dim_ODMD-',num2str(index),'.pdf');
strPlotFilePDF5=strcat(strPlotPath,'\Dim_COV_ODMD-',num2str(index),'.pdf');
strPlotFilePDF6=strcat(strPlotPath,'\Dim_DMD_ODMD-',num2str(index),'.pdf');
strPlotFilePDF7=strcat(strPlotPath,'\PoolProfile-',num2str(index),'.pdf');
strSaveFileMAT1=strcat(strDataPath,'\MAT\kATP_pool_parameters-',num2str(index),'.mat');
strSaveFileMAT2=strcat(strDataPath,'\MAT\kATP_pools-',num2str(index),'.mat');

%% Load data
load(strReadFileMAT1,'spl','Css_data');
load(strReadFileMAT2,'n_met');

%% Parameters
i_sample=1;
n_w=150;                       % number of grid intervals to be generated in the moving time window in which TSD is performed
n_tp_w=30;                     % number of time points to be included in the time window in which TSD is performed
n_tp_inp=350;                  % number of time point in the inerval [T1,T2]
n_tw_inp=n_tp_inp-n_tp_w+1;    % number of time windows of length n_tp_w in the inerval [T1,T2]

T_inf=300;
T1=1e-7;
T2=T_inf;
n_tp_inp=350;
r_inp=1.063;

tol_dm_cov=0.03;                 % order-of-magnitude cut-off used to determine the dimensionality from the covariance of trajectories
tol_dm_dmd=0.082;                 % order-of-magnitude cut-off used to determine the dimensionality in the dynamic mode decomposition method
tol_xi=0.2;                     % order-of-magnitude cut-off used to determine the dominant amplitudes of optimal dynamic modes
dig_round=6;                    % # significant digits to which two dominant amplitude are considered the same 

ind_pool_plot=[290,1;321,1];
n_pool_plot=size(ind_pool_plot,1);

%% Memory allocations
lambda_dom=zeros(n_met,n_tw_inp);
dim_cov=zeros(1,n_tw_inp);
dim_dmd=zeros(1,n_tw_inp);
t_inp=zeros(1,n_tp_inp);
pools=cell(n_tw_inp,1);

%% Format data
sol.x=spl{i_sample}.t_data';
sol.y=spl{i_sample}.C_data';
x_ss=Css_data';
u=sol.y-x_ss;

%% Interpolation setup
dt_inp=(T2-T1)*(1-r_inp)/(1-r_inp^(n_tp_inp-1));
t_inp(1)=T1;
for i=2:n_tp_inp
    t_inp(i)=t_inp(i-1)+r_inp^(i-2)*dt_inp;
end
x_inp=interp1(sol.x',sol.y',t_inp,'spline')';
u_inp=interp1(sol.x',u',t_inp,'spline')';

%% Determining the spectrum

% Pools
n_dm_dmd_max=0;
i_w=n_tw_inp;
while i_w>=1
    i1=i_w;
    i2=i_w+n_tp_w-1;
    dt=(t_inp(i2)-t_inp(i1))/n_w;
    t_w0=linspace(t_inp(i1),t_inp(i2),n_w+1);
    t_w1=linspace(t_inp(i1)+dt,t_inp(i2)+dt,n_w+1);
    x_inp_w0=interp1(t_inp,x_inp',t_w0,'spline')';
    x_inp_w1=interp1(t_inp,x_inp',t_w1,'spline')';
    u_inp_w0=interp1(t_inp,u_inp',t_w0,'spline')';
    h_inp_w0=x_inp_w0-x_inp_w1(:,n_w+1);              
    h_inp_w1=x_inp_w1-x_inp_w1(:,n_w+1); 

    % DMD method
    % -- differential time series data matrices
    Dh=h_inp_w1-h_inp_w0;

    % -- proper orthogonal modes
    [U0,S0,~]=svd(h_inp_w0);

    % -- number of dominant eigenvalues of proper orthogonal modes
    n_mu=n_met;
    log_span_max=log10(S0(1,1)/S0(n_met,n_met));
    for i=1:n_met-1
        if log10(S0(i,i)/S0(i+1,i+1))>tol_dm_dmd*log_span_max
            n_mu=i;
            break;
        end
    end

    % -- reduced proper orthogonal modes
    U0r=U0(:,1:n_mu);

    % -- projecting time series data onto reduced space of proper orthogonal modes 
    hh_inp_w0=U0r'*h_inp_w0;
    hh_inp_w1=U0r'*h_inp_w1;
    hh_inp_w0_av=mean(hh_inp_w0,2);
    hh_inp_w1_av=mean(hh_inp_w1,2);

    % -- covariance of time series data
    XX0=hh_inp_w0*hh_inp_w0'/(n_w+1)-hh_inp_w0_av*hh_inp_w0_av';
    XX10=hh_inp_w1*hh_inp_w0'/(n_w+1)-hh_inp_w1_av*hh_inp_w0_av';
    
    % -- optimal Hessenburg form of A 
    F=XX10/XX0;

    % -- memory allocation
    mu_all=zeros(n_mu,1);
    V_vand=[ones(n_mu,1),zeros(n_mu,n_w)];

    % -- eigenvlaues in the reduced space of proper orthogonal modes
    [Y,MU]=eig(F);   
    for i=1:n_mu
        mu_all(i)=MU(i,i);
    end

    % -- proper orthogonal modes of differential time series data
    [UU,SS,VV]=svd(Dh);

    % -- reduced proper orthogonal modes of differential time series data
    SSr=SS(1:n_mu,1:n_mu);
    UUr=UU(:,1:n_mu);
    VVr=VV(:,1:n_mu);
    
    % -- optimal amplitudes and dynamic modes
    for i=1:n_mu
        for i_t=1:n_w
            V_vand(i,i_t+1)=MU(i,i)^i_t;
        end
    end
    U_corr=UUr'*U0r;
    Y_corr=U_corr*Y;          % we could assume that proper orthogonal modes of h_inp_w0 and Dh are almost the same, in which case UUr'*U0r=eye(n_mu). However, here we account for corrections to avoid even small errors.
    YY=Y_corr'*Y_corr;
    VV_vand=conj(V_vand*V_vand');
    q=diag(conj(V_vand*VVr*SSr'*Y_corr));
    P=YY.*VV_vand;
    alpha_all=pinv(P)*q;
    alpha_norm_all=abs(alpha_all);
    PHI_all=U0r*Y;

    % -- dominant amplitudes and optimal dynamic modes
    alpha_norm_all=round(alpha_norm_all,dig_round,'significant');
    [alpha_norm_all1,I1,~]=unique(alpha_norm_all,'stable');
    [alpha_norm,I2]=sort(alpha_norm_all1,'descend');
    I=I1(I2);
    alpha=alpha_all(I);
    PHI=PHI_all(:,I);
    mu=mu_all(I);
    V_vand=V_vand(I,:);

    mu_norm=abs(mu);
    xi=alpha_norm.*mu_norm.^n_w;
    n_mu=size(mu,1);
    
    n_dm=n_mu;
    log_span_max=log10(xi(1)/xi(n_mu));
    for i=1:n_mu-1
        if log10(xi(i)/xi(i+1))>tol_xi*log_span_max
            n_dm=i;
            break;
        end
    end
    
    alpha=alpha(1:n_dm);
    Da=diag(alpha);
    PHI=PHI(:,1:n_dm);
    mu=mu(1:n_dm);
    V_vand=V_vand(1:n_dm,:);
    TH=PHI*Da;
    
    % -- dominant eigenvalues of exponential decay modes
    lambda=log(mu)/dt;

    % -- estimate error
    err=norm(Dh-PHI*Da*V_vand)/norm(Dh);

    % -- pooling matrix
    W=pinv(TH);
    for i=1:n_dm
        W(i,:)=W(i,:)/norm(W(i,:));
    end

    % -- maximum dimension (DMD)
    n_dm_dmd_max=max(n_dm,n_dm_dmd_max);
         
    % -- storing results (DMD)
    pools{i_w}.TH=real(TH);
    pools{i_w}.W=real(W);
    pools{i_w}.lambda=lambda;
    pools{i_w}.alpha=alpha;
    pools{i_w}.n_dm_dmd=n_dm; 

    % Covariance method (only for dimensionality)
    % -- dimensionality
    u_inp_w0_av=mean(u_inp_w0,2);
    X_u=u_inp_w0*u_inp_w0'/(n_w+1)-u_inp_w0_av*u_inp_w0_av';
    ss=svd(X_u);

    n_dm=n_met;
    log_span_max=log10(ss(1)/ss(n_met));
    for i=1:n_met-1
        if log10(ss(i)/ss(i+1))>tol_dm_cov*log_span_max
            n_dm=i;
            break;
        end
    end

    % -- storing results (Covariance)
    pools{i_w}.n_dm_cov=n_dm; 

    % Storing variables for plots
    for i=1:pools{i_w}.n_dm_dmd
        lambda_dom(i,i_w)=lambda(i);
    end
    dim_cov(i_w)=pools{i_w}.n_dm_cov;
    dim_dmd(i_w)=pools{i_w}.n_dm_dmd;
    
    % Report status
    if pools{i_w}.n_dm_dmd==1
        fprintf('i_w=%d: t1=%.2e, t2=%.2e, dim_cov=%d, dim_dmd=%d, lmb_1=%e, err=%e\n',i_w,t_inp(i1),t_inp(i2),pools{i_w}.n_dm_cov,pools{i_w}.n_dm_dmd,lambda(1),err);
    elseif pools{i_w}.n_dm_dmd==2
        fprintf('i_w=%d: t1=%.2e, t2=%.2e, dim_cov=%d, dim_dmd=%d, lmb_1=%e, lmb_2=%e, err=%e\n',i_w,t_inp(i1),t_inp(i2),pools{i_w}.n_dm_cov,pools{i_w}.n_dm_dmd,lambda(1),lambda(2),err);
    elseif pools{i_w}.n_dm_dmd==3
        fprintf('i_w=%d: t1=%.2e, t2=%.2e, dim_cov=%d, dim_dmd=%d, lmb_1=%e, lmb_2=%e, lmb_3=%e, err=%e\n',i_w,t_inp(i1),t_inp(i2),pools{i_w}.n_dm_cov,pools{i_w}.n_dm_dmd,lambda(1),lambda(2),lambda(3),err);
    elseif pools{i_w}.n_dm_dmd==4
        fprintf('i_w=%d: t1=%.2e, t2=%.2e, dim_cov=%d, dim_dmd=%d, lmb_1=%e, lmb_2=%e, lmb_3=%e, lmb_4=%e, err=%e\n',i_w,t_inp(i1),t_inp(i2),pools{i_w}.n_dm_cov,pools{i_w}.n_dm_dmd,lambda(1),lambda(2),lambda(3),lambda(4),err);
    elseif pools{i_w}.n_dm_dmd==5
        fprintf('i_w=%d: t1=%.2e, t2=%.2e, dim_cov=%d, dim_dmd=%d, lmb_1=%e, lmb_2=%e, lmb_3=%e, lmb_4=%e, lmb_5=%e, err=%e\n',i_w,t_inp(i1),t_inp(i2),pools{i_w}.n_dm_cov,pools{i_w}.n_dm_dmd,lambda(1),lambda(2),lambda(3),lambda(4),lambda(5),err);
    else
        fprintf('i_w=%d: t1=%.2e, t2=%.2e, dim_cov=%d, dim_dmd=%d, lmb_1=%e, lmb_2=%e, lmb_3=%e, lmb_4=%e, lmb_5=%e, lmb_6=%e, err=%e\n',i_w,t_inp(i1),t_inp(i2),pools{i_w}.n_dm_cov,pools{i_w}.n_dm_dmd,lambda(1),lambda(2),lambda(3),lambda(4),lambda(5),lambda(6),err);
    end
    
    % Update loop index
    i_w=i_w-1;
end

%% Save data
save(strSaveFileMAT1,'n_met','T_inf','T1','T2','r_inp','n_w','n_tp_w','n_tp_inp','n_dm_dmd_max','tol_dm_cov','tol_dm_dmd','tol_xi','dig_round');
save(strSaveFileMAT2,'pools');

%% Plot settings
line_color_met=cell(n_met,1);
met_first_color=[0, 0, 255]/255;
met_last_color=[255, 0, 0]/255;
met_colormap=customcolormap([0,1],[met_last_color;met_first_color],n_met);

for i=1:n_met
   line_color_met{i}=met_colormap(i,:);
end
LW_met=2;

line_color_lmb=cell(n_met,1);
lmb_first_color=[27, 92, 32]/255;
lmb_last_color=[245, 250, 170]/255;
lmb_colormap=customcolormap([0,1],[lmb_last_color;lmb_first_color],n_met);

for i=1:n_met
   line_color_lmb{i}=lmb_colormap(i,:);
end
LW_lmb=2;

line_color_pool=cell(n_pool_plot,1);
pool_first_color=[50, 156, 26]/255;
pool_last_color=[247, 154, 5]/255;
pool_colormap=customcolormap([0,1],[pool_last_color;pool_first_color],n_pool_plot);

for i=1:n_pool_plot
   line_color_pool{i}=pool_colormap(i,:);
end
LW_pool=2;

line_color_dim_cov=[0 0 255]/255;
line_color_dim_dmd=[255 0 0]/255;

xlim_arg=[T1 1e3];
xticks_arg=[1e-7 1e-5 1e-3 1e-1 1e1 1e3];
%xticks_arg='auto';

%% Plots
hh1=figure;
for i=1:n_met
    plot(sol.x,u(i,:),'-','Color',line_color_met{i},'LineWidth',LW_met);
    hold on
end
n_dm_old=1;
for i_w=1:n_tw_inp
    i1=i_w;
    if pools{i_w}.n_dm_cov~=n_dm_old
        xline((t_inp(i1)+t_inp(i1+1))/2,'--k','LineWidth',1);
        hold on
    end
    n_dm_old=pools{i_w}.n_dm_cov;
end

xlabel('$t$ (hr)','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
ylabel('$x-x^{\mathrm{ss}}$ (mM)','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
xlim(xlim_arg);
xticks(xticks_arg);
set(gca,'XScale','log');
set(gca,'FontSize',18,'FontName','Times New Roman');
set(gcf,'PaperUnits', 'centimeters');
set(gcf,'PaperSize', [20 16]);
set(gcf,'PaperPosition', [0 0 20 16]);

hh2=figure;
for i=1:n_met
    plot(sol.x,u(i,:),'-','Color',line_color_met{i},'LineWidth',LW_met);
    hold on
end
n_dm_old=1;
for i_w=1:n_tw_inp
    i1=i_w;
    if pools{i_w}.n_dm_dmd~=n_dm_old
        xline((t_inp(i1)+t_inp(i1+1))/2,'--k','LineWidth',1);
        hold on
    end
    n_dm_old=pools{i_w}.n_dm_dmd;
end

xlabel('$t$ (hr)','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
ylabel('$x-x^{\mathrm{ss}}$ (mM)','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
xlim(xlim_arg);
xticks(xticks_arg);
set(gca,'XScale','log');
set(gca,'FontSize',18,'FontName','Times New Roman');
set(gcf,'PaperUnits', 'centimeters');
set(gcf,'PaperSize', [20 16]);
set(gcf,'PaperPosition', [0 0 20 16]);

hh3=figure;
for i=1:n_met
    plot(t_inp(1:n_tw_inp),abs(lambda_dom(i,:)),'-','Color',line_color_lmb{i},'LineWidth',LW_lmb);
    hold on
end
n_dm_old=1;
for i_w=1:n_tw_inp
    i1=i_w;
    if pools{i_w}.n_dm_dmd~=n_dm_old
        xline((t_inp(i1)+t_inp(i1+1))/2,'--k','LineWidth',1);
        hold on
    end
    n_dm_old=pools{i_w}.n_dm_dmd;
end

xlabel('$t$ (hr)','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
ylabel('$|\lambda|$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
xlim(xlim_arg);
xticks(xticks_arg);
set(gca,'XScale','log','YScale','log');
set(gca,'FontSize',18,'FontName','Times New Roman');
set(gcf,'PaperUnits', 'centimeters');
set(gcf,'PaperSize', [20 16]);
set(gcf,'PaperPosition', [0 0 20 16]);

hh4=figure;
plot(t_inp(1:n_tw_inp),dim_cov,'-','Color',line_color_dim_cov,'LineWidth',2);
hold on
plot(t_inp(1:n_tw_inp),dim_dmd,'-','Color',line_color_dim_dmd,'LineWidth',2);

xlabel('$t$ (hr)','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
ylabel('dimensionality','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
xlim(xlim_arg);
xticks(xticks_arg);
set(gca,'XScale','log');
set(gca,'FontSize',18,'FontName','Times New Roman');
set(gcf,'PaperUnits', 'centimeters');
set(gcf,'PaperSize', [20 5]);
set(gcf,'PaperPosition', [0 0 20 5]);

hh5=figure;
plot(t_inp(1:n_tw_inp),dim_cov,'-','Color',line_color_dim_cov,'LineWidth',2);
hold on
n_dm_old=1;
for i_w=1:n_tw_inp
    i1=i_w;
    if pools{i_w}.n_dm_cov~=n_dm_old
        xline((t_inp(i1)+t_inp(i1+1))/2,'--k','LineWidth',1);
        hold on
    end
    n_dm_old=pools{i_w}.n_dm_cov;
end

xlabel('$t$ (hr)','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
ylabel('dimensionality','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
xlim(xlim_arg);
xticks(xticks_arg);
set(gca,'XScale','log');
set(gca,'FontSize',18,'FontName','Times New Roman');
set(gcf,'PaperUnits', 'centimeters');
set(gcf,'PaperSize', [20 5]);
set(gcf,'PaperPosition', [0 0 20 5]);

hh6=figure;
plot(t_inp(1:n_tw_inp),dim_dmd,'-','Color',line_color_dim_dmd,'LineWidth',2);
hold on
n_dm_old=1;
for i_w=1:n_tw_inp
    i1=i_w;
    if pools{i_w}.n_dm_dmd~=n_dm_old
        xline((t_inp(i1)+t_inp(i1+1))/2,'--k','LineWidth',1);
        hold on
    end
    n_dm_old=pools{i_w}.n_dm_dmd;
end

xlabel('$t$ (hr)','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
ylabel('dimensionality','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
xlim(xlim_arg);
xticks(xticks_arg);
set(gca,'XScale','log');
set(gca,'FontSize',18,'FontName','Times New Roman');
set(gcf,'PaperUnits', 'centimeters');
set(gcf,'PaperSize', [20 5]);
set(gcf,'PaperPosition', [0 0 20 5]);

hh7=figure;
for i=1:n_pool_plot
    %ws=pools{ind_pool_plot(i,1)}.W(ind_pool_plot(i,2),:)*S;
    p=abs(pools{ind_pool_plot(i,1)}.W(ind_pool_plot(i,2),:)*sol.y);
    plot(sol.x,p,'-','Color',line_color_pool{i},'LineWidth',LW_pool);
    hold on
end
n_dm_old=1;
for i_w=1:n_tw_inp
    i1=i_w;
    if pools{i_w}.n_dm_dmd~=n_dm_old
        xline((t_inp(i1)+t_inp(i1+1))/2,'--k','LineWidth',1);
        hold on
    end
    n_dm_old=pools{i_w}.n_dm_dmd;
end

xlabel('$t$ (hr)','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
ylabel('$p$ (mM)','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
xlim(xlim_arg);
xticks(xticks_arg);
set(gca,'XScale','log');
set(gca,'FontSize',18,'FontName','Times New Roman');
set(gcf,'PaperUnits', 'centimeters');
set(gcf,'PaperSize', [20 16]);
set(gcf,'PaperPosition', [0 0 20 16]);

%% Print Plots
print(hh1,'-dpdf',strPlotFilePDF1);
print(hh2,'-dpdf',strPlotFilePDF2);
print(hh3,'-dpdf',strPlotFilePDF3);
print(hh4,'-dpdf',strPlotFilePDF4);
print(hh5,'-dpdf',strPlotFilePDF5);
print(hh6,'-dpdf',strPlotFilePDF6);
print(hh7,'-dpdf',strPlotFilePDF7);
return



