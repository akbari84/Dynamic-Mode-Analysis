function PlotTrajTimeGrid()
clc;

%% Path string parameters
index=2;         
grid_on=1;

%% Path strings
% Replace WorkingDirectory with your working directory in all the file paths.
strPlotPath='WorkingDirectory\Glycolysis\Plots\kATP';
strDataPath='WorkingDirectory\Glycolysis\Shared-data';
strReadFileMAT1=strcat(strDataPath,'\MAT\kATP_concentrations-',num2str(index),'.mat');
strReadFileMAT2=strcat(strDataPath,'\MAT\parameters-',num2str(index),'.mat');
if grid_on==1
    strPlotFilePDF1=strcat(strPlotPath,'\ConcDeviationProfile_grid-',num2str(index),'.pdf');
    strPlotFilePDF2=strcat(strPlotPath,'\ConcProfile_grid-',num2str(index),'.pdf');
end
if grid_on==0
    strPlotFilePDF1=strcat(strPlotPath,'\ConcDeviationProfile-',num2str(index),'.pdf');
    strPlotFilePDF2=strcat(strPlotPath,'\ConcProfile-',num2str(index),'.pdf');
end

%% Load data
load(strReadFileMAT1,'spl','Css_data');
load(strReadFileMAT2,'n_met');

%% Parameters
T_inf=300;
T1=1e-7;
T2=T_inf;
n_tp_inp=350;
r_inp=1.063;

i_sample=1;

%% Memory allocations
t_inp=zeros(n_tp_inp,1);
line_color_met=cell(n_met,1);

%% Format data
t=spl{i_sample}.t_data';
x=spl{i_sample}.C_data';
x_ss=Css_data';
u=x-x_ss;

%% Interpolation setup
dt_inp=(T2-T1)*(1-r_inp)/(1-r_inp^(n_tp_inp-1));
t_inp(1)=T1;
for i=2:n_tp_inp
    t_inp(i)=t_inp(i-1)+r_inp^(i-2)*dt_inp;
end

%% Plot settings
met_first_color=[0, 0, 255]/255;
met_last_color=[255, 0, 0]/255;
met_colormap=customcolormap([0,1],[met_last_color;met_first_color],n_met);

for i=1:n_met
   line_color_met{i}=met_colormap(i,:);
end
LW_traj=2;

%% Plots
hh1=figure;
for i=1:n_met
    plot(t,u(i,:),'-','Color',line_color_met{i},'LineWidth',LW_traj);
    hold on
end
if grid_on
    for i=1:n_tp_inp
        xline(t_inp(i),'--k');
        hold on
    end
end

xlabel('$t$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
ylabel('$u$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
set(gca,'FontSize',18,'FontName','Times New Roman');
if grid_on 
    set(gca,'XScale','log');
else
    set(gca,'XScale','log','XGrid','on','YGrid','on','XMinorGrid','on','YMinorGrid','on','MinorGridLineStyle',':');
end
set(gcf,'PaperUnits', 'centimeters');
set(gcf,'PaperSize', [25 10]);
set(gcf,'PaperPosition', [0 0 25 10]);

hh2=figure;
for i=1:n_met
    plot(t,x(i,:),'-','Color',line_color_met{i},'LineWidth',LW_traj);
    hold on
end
if grid_on
    for i=1:n_tp_inp
        xline(t_inp(i),'--k');
        hold on
    end
end

xlabel('$t$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
ylabel('$x$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
set(gca,'FontSize',18,'FontName','Times New Roman');
if grid_on 
    set(gca,'XScale','log');
else
    set(gca,'XScale','log','XGrid','on','YGrid','on','XMinorGrid','on','YMinorGrid','on','MinorGridLineStyle',':');
end
set(gcf,'PaperUnits', 'centimeters');
set(gcf,'PaperSize', [25 10]);
set(gcf,'PaperPosition', [0 0 25 10]);


%% Print Plots
print(hh1,'-dpdf',strPlotFilePDF1);
print(hh2,'-dpdf',strPlotFilePDF2);

return

