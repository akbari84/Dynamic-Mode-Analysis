function WritePools_ODMD()
clc;

%% Parameters to set up path strings 
index=1;

%% Path strings
% Replace WorkingDirectory with your working directory in all the file paths.
strDataPath='WorkingDirectory\Toy-models\Shared-data';
strResultsPath='WorkingDirectory\Toy-models\Result-sheets';
strWriteFileEXL1=strcat(strResultsPath,'\toy2_pools-',num2str(index),'.xlsx');
strReadFileMAT1=strcat(strDataPath,'\MAT\pool_parameters_toy2-',num2str(index),'.mat');
strReadFileMAT2=strcat(strDataPath,'\MAT\toy2_pool-',num2str(index),'.mat');

%% Load data
load(strReadFileMAT1,'n_met','n_dm_dmd_max','T1','T2','r_inp','n_tp_w','n_tp_inp');
load(strReadFileMAT2,'pools');

%% Parameters
n_tw_inp=n_tp_inp-n_tp_w+1;    % number of time windows of length n_tp_w in the inerval [T1,T2]

%% Memory allocations
t_inp=zeros(1,n_tp_inp);

%% Interpolation setup
dt_inp=(T2-T1)*(1-r_inp)/(1-r_inp^(n_tp_inp-1));
t_inp(1)=T1;
for i=2:n_tp_inp
    t_inp(i)=t_inp(i-1)+r_inp^(i-2)*dt_inp;
end

%% Write to Excel sheet
% Header:
xlSheet='Pools';
xlRange=strcat(xlscol(1),'1:',xlscol(n_dm_dmd_max*(n_met+2)+3),'1');
strCell=cell(1,(n_met+2)*n_dm_dmd_max+3);
strCell{1}='i_w';
strCell{2}='t_inp_1';
strCell{3}='t_inp_2';
for i=1:n_dm_dmd_max
    for j=1:n_met
        i_col=(i-1)*(n_met+2)+j+4;
        strCell{i_col}=strcat('x',num2str(j));
    end
    i_col=(i-1)*(n_met+2)+n_met+5;
    strCell{i_col}=strcat('lmb_',num2str(i));
end
writecell(strCell,strWriteFileEXL1,'sheet',xlSheet,'range',xlRange);

% Pool data:
for i_w=1:n_tw_inp
    i1=i_w;
    i2=i_w+n_tp_w-1;
    xlRange=strcat(xlscol(1),num2str(i_w+1));
    writematrix(i_w,strWriteFileEXL1,'sheet',xlSheet,'range',xlRange);
    xlRange=strcat(xlscol(2),num2str(i_w+1));
    writematrix(t_inp(i1),strWriteFileEXL1,'sheet',xlSheet,'range',xlRange);
    xlRange=strcat(xlscol(3),num2str(i_w+1));
    writematrix(t_inp(i2),strWriteFileEXL1,'sheet',xlSheet,'range',xlRange);
    for i=1:pools{i_w}.n_dm_dmd
        i_col1=(i-1)*(n_met+2)+5;
        i_col2=(i-1)*(n_met+2)+n_met+4;
        xlRange=strcat(xlscol(i_col1),num2str(i_w+1),':',xlscol(i_col2),num2str(i_w+1));
        writematrix(pools{i_w}.W(i,:),strWriteFileEXL1,'sheet',xlSheet,'range',xlRange);

        i_col=(i-1)*(n_met+2)+n_met+5;
        xlRange=strcat(xlscol(i_col),num2str(i_w+1));
        writematrix(pools{i_w}.lambda(i),strWriteFileEXL1,'sheet',xlSheet,'range',xlRange);
    end
end

return