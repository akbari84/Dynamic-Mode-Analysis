function PlotTrajTimeGrid()
clc;

%% Path string parameters
index=2;
grid_on=1;

%% Path strings
% Replace WorkingDirectory with your working directory in all the file paths.
strPlotPath='WorkingDirectory\Toy-models\Plots\Toy2';
if grid_on==1
    strPlotFilePDF1=strcat(strPlotPath,'\ConcDeviationProfile_grid-',num2str(index),'.pdf');
    strPlotFilePDF2=strcat(strPlotPath,'\ConcProfile_grid-',num2str(index),'.pdf');
    strPlotFilePDF3=strcat(strPlotPath,'\FluxProfile_grid-',num2str(index),'.pdf');
end
if grid_on==0
    strPlotFilePDF1=strcat(strPlotPath,'\ConcDeviationProfile-',num2str(index),'.pdf');
    strPlotFilePDF2=strcat(strPlotPath,'\ConcProfile-',num2str(index),'.pdf');
    strPlotFilePDF3=strcat(strPlotPath,'\FluxProfile-',num2str(index),'.pdf');
end

%% Parameters
kp_={[0.001;1;0.01;1;0.001;2;1];
     [0.001;0.0001;0.01;0.0001;0.001;2;1]};  % k_PERC
Keq=[1;1;1;1;1;1;1];
u0=[0;-0.001;0;0.001;0.01;-0.01];
x_out=[0.2;0;0;0.1;0.2;0.1];

T_inf_=[4.5e4;3e6];
T1=1e-3;
T2_=T_inf_;
n_tp_inp=350;
r_inp_=[1.052;1.065];

kp=kp_{index};
T_inf=T_inf_(index);
T2=T2_(index);
r_inp=r_inp_(index);

n_met=size(u0,1);
n_rxn=size(kp,1);

%% Memory allocations
t_inp=zeros(n_tp_inp,1);
line_color_met=cell(n_met,1);

%% k_PERC of reverse reactions
kn=kp./Keq;

%% Stoichiometry & G & vv 
S=[1 -1 0 0 0 0 0
   0 2 -1 0 0 0 0
   0 0 1 -1 0 0 0
   0 0 0 1 -1 0 0
   0 -1 0 1 0 1 0
   0 1 0 -1 0 0 1];

%% Steady-state mass-balance
x_0=[x_out(1);0;0;x_out(4);x_out(5);x_out(6)];
t=1;
options=optimoptions('fsolve','TolFun',1e-10);
[x_ss,~]=fsolve(@(x)Fun_ode(t,x,x_out,S,kp,kn),x_0,options);

%% Solving mass-balance equations
x0=x_ss+u0;

options=odeset('RelTol',1e-10,'AbsTol',1e-10);
sol=ode15s(@(t,x)Fun_ode(t,x,x_out,S,kp,kn),[0,1.00000001*T_inf],x0,options);
t=sol.x;
x=sol.y;
u=x-x_ss;
n_t=size(t,2);

%% Calculate fluxes
v=zeros(n_rxn,n_t);
for i=1:n_t
    v(:,i)=Fun_flux(sol.y(:,i),x_out,kp,kn);
end

%% Interpolation setup
dt_inp=(T2-T1)*(1-r_inp)/(1-r_inp^(n_tp_inp-1));
t_inp(1)=T1;
for i=2:n_tp_inp
    t_inp(i)=t_inp(i-1)+r_inp^(i-2)*dt_inp;
end

%% Plot settings
met_first_color=[0, 0, 255]/255;
met_last_color=[255, 0, 0]/255;
met_colormap=customcolormap([0,1],[met_last_color;met_first_color],n_met);

for i=1:n_met
   line_color_met{i}=met_colormap(i,:);
end
LW_traj=2;

line_color_rxn=cell(n_rxn,1);
rxn_first_color=[0, 0, 255]/255;
rxn_last_color=[255, 0, 0]/255;
rxn_colormap=customcolormap([0,1],[rxn_last_color;rxn_first_color],n_rxn);

for i=1:n_rxn
   line_color_rxn{i}=rxn_colormap(i,:);
end
LW_rxn=2;

%% Plots
hh1=figure;
for i=1:n_met
    plot(t,u(i,:),'-','Color',line_color_met{i},'LineWidth',LW_traj);
    hold on
end
if grid_on
    for i=1:n_tp_inp
        xline(t_inp(i),'--k');
        hold on
    end
end

xlabel('$t$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
ylabel('$u$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
set(gca,'FontSize',18,'FontName','Times New Roman');
if grid_on 
    set(gca,'XScale','log');
else
    set(gca,'XScale','log','XGrid','on','YGrid','on','XMinorGrid','on','YMinorGrid','on','MinorGridLineStyle',':');
end
set(gcf,'PaperUnits', 'centimeters');
set(gcf,'PaperSize', [25 10]);
set(gcf,'PaperPosition', [0 0 25 10]);

hh2=figure;
for i=1:n_met
    plot(t,x(i,:),'-','Color',line_color_met{i},'LineWidth',LW_traj);
    hold on
end
if grid_on
    for i=1:n_tp_inp
        xline(t_inp(i),'--k');
        hold on
    end
end

xlabel('$t$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
ylabel('$x$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
set(gca,'FontSize',18,'FontName','Times New Roman');
if grid_on 
    set(gca,'XScale','log');
else
    set(gca,'XScale','log','XGrid','on','YGrid','on','XMinorGrid','on','YMinorGrid','on','MinorGridLineStyle',':');
end
set(gcf,'PaperUnits', 'centimeters');
set(gcf,'PaperSize', [25 10]);
set(gcf,'PaperPosition', [0 0 25 10]);

hh3=figure;
for i=1:n_rxn
    plot(t,v(i,:),'-','Color',line_color_rxn{i},'LineWidth',LW_rxn);
    hold on
end
if grid_on
    for i=1:n_tp_inp
        xline(t_inp(i),'--k');
        hold on
    end
end

xlabel('$t$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
ylabel('$v$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
set(gca,'FontSize',18,'FontName','Times New Roman');
if grid_on 
    set(gca,'XScale','log');
else
    set(gca,'XScale','log','XGrid','on','YGrid','on','XMinorGrid','on','YMinorGrid','on','MinorGridLineStyle',':');
end
set(gcf,'PaperUnits', 'centimeters');
set(gcf,'PaperSize', [25 10]);
set(gcf,'PaperPosition', [0 0 25 10]);

%% Print Plots
print(hh1,'-dpdf',strPlotFilePDF1);
print(hh2,'-dpdf',strPlotFilePDF2);
print(hh3,'-dpdf',strPlotFilePDF3);

return

function dxdt=Fun_ode(~,x,x_out,S,kp,kn)
    v=zeros(7,1);
    
    v(1)=kp(1)*x_out(1)-kn(1)*x(1);
    v(2)=kp(2)*x(1)*x(5)-kn(2)*x(2)^2*x(6);
    v(3)=kp(3)*x(2)-kn(3)*x(3);
    v(4)=kp(4)*x(3)*x(6)-kn(4)*x(4)*x(5);
    v(5)=kp(5)*x(4)-kn(5)*x_out(4);
    v(6)=kp(6)*x_out(5)-kn(6)*x(5);
    v(7)=kp(7)*x_out(6)-kn(7)*x(6);

    dxdt=S*v;
return

function v=Fun_flux(x,x_out,kp,kn)
    v=zeros(7,1);
    
    v(1)=kp(1)*x_out(1)-kn(1)*x(1);
    v(2)=kp(2)*x(1)*x(5)-kn(2)*x(2)^2*x(6);
    v(3)=kp(3)*x(2)-kn(3)*x(3);
    v(4)=kp(4)*x(3)*x(6)-kn(4)*x(4)*x(5);
    v(5)=kp(5)*x(4)-kn(5)*x_out(4);
    v(6)=kp(6)*x_out(5)-kn(6)*x(5);
    v(7)=kp(7)*x_out(6)-kn(7)*x(6);
return