function PoolRepresentations()
clc;

%% Path string parameters
index=1;
n_pool_max=4;

strPlotFilePDF4=cell(n_pool_max,1);

%% Path strings
% Replace WorkingDirectory with your working directory in all the file paths.
strPlotPath='WorkingDirectory\Toy-models\Plots\Toy1';
strPlotFilePDF1=strcat(strPlotPath,'\ConcProfile-',num2str(index),'.pdf');
strPlotFilePDF2=strcat(strPlotPath,'\ConcDeviationProfile-',num2str(index),'.pdf');
strPlotFilePDF3=strcat(strPlotPath,'\FluxProfile-',num2str(index),'.pdf');
for i=1:n_pool_max
    strPlotFilePDF4{i}=strcat(strPlotPath,'\Pool_',num2str(i),'_Profile-',num2str(index),'.pdf');
end

%% Parameters
kp=[0.000001;1;0.01;0.0001;0.000001];        % k_PERC
Keq=[1;1;1;1;1];
u0=[0.1;0;0;-0.1];
C_out=[1;0;0;0.1];

T_inf=5e7;

n_met=size(u0,1);
n_rxn=size(kp,1);
n_pool=4;

%% Memory allocartion
pp=cell(n_pool,1);
n_pp=zeros(n_pool,1);
line_color_met=cell(n_met,1);
line_color_rxn=cell(n_rxn,1);
line_color_pool=cell(n_pool+1,1);

%% Plot settings
met_first_color=[0, 0, 255]/255;
met_last_color=[255, 0, 0]/255;
met_colormap=customcolormap([0,1],[met_last_color;met_first_color],n_met);

for i=1:n_met
   line_color_met{i}=met_colormap(i,:);
end

rxn_first_color=[28, 112, 4]/255;
rxn_last_color=[240, 213, 125]/255;
rxn_colormap=customcolormap([0,1],[rxn_last_color;rxn_first_color],n_rxn);

for i=1:n_rxn
   line_color_rxn{i}=rxn_colormap(i,:);
end

pool_first_color=[214, 100, 43]/255;
pool_last_color=[66, 165, 212]/255;
pool_colormap=customcolormap([0,1],[pool_last_color;pool_first_color],n_pool);

for i=1:n_pool
   line_color_pool{i}=pool_colormap(i,:);
end
line_color_sumpool=[0, 0, 0]/255;

LW_traj=2;

%% k_PERC of reverse reactions
kn=kp./Keq;

%% Stoichiometry & G & vv
S=[1 -1 0 0 0
   0 1 -1 0 0
   0 0 1 -1 0
   0 0 0 1 -1];

G=[-kn(1) 0 0 0
    kp(2) -kn(2) 0 0
    0 kp(3) -kn(3) 0
    0 0 kp(4) -kn(4)
    0 0 0 kp(5)];

vv=[-kp(1)*C_out(1);0;0;0;kn(1)*C_out(4)];

%% Jacobian
J=S*G;

%% Steady state solution
Css=J\S*vv;

kappa=1/(Keq(2)*Keq(3)*Keq(4)*Keq(5)/kn(1)+Keq(3)*Keq(4)*Keq(5)/kn(2)+Keq(4)*Keq(5)/kn(3)+Keq(5)/kn(4)+1/kn(5));        % effective forward turnover number
KKeq=Keq(1)*Keq(2)*Keq(3)*Keq(4)*Keq(5);                                                                                % overall equilibrium constant
eta=1-(C_out(4)/C_out(1))/KKeq;                                                                                         % overall thermodynamic driving force   
v_ss=kappa*eta*KKeq*C_out(1);

%% Solving mass-balance equations
sol=ode15s(@(t,u)Fun_ode(t,u,J),[0,T_inf],u0);
t=sol.x;
u=sol.y;
n_t=size(t,2);

%% Trajectories
C=u+Css;
v=G*C-vv;

%% Constructing pools
% Pool strucutre - memory allocation
for i=1:n_pool
    n_pp(i)=i+1;
    pp{i}=zeros(n_pp(i),n_t);
end

% Computing sub-reprenetations of pools
for j=1:n_t
    pp{1}(1,j)=Keq(2)*C(1,j)-C(2,j);

    pp{2}(1,j)=Keq(3)*C(2,j)-C(3,j);
    pp{2}(2,j)=Keq(2)*Keq(3)*C(1,j)-C(3,j);

    pp{3}(1,j)=Keq(4)*C(3,j)-C(4,j);
    pp{3}(2,j)=Keq(3)*Keq(4)*C(2,j)-C(4,j);
    pp{3}(3,j)=Keq(2)*Keq(3)*Keq(4)*C(1,j)-C(4,j);

    pp{4}(1,j)=Keq(5)*C(4,j);
    pp{4}(2,j)=Keq(4)*Keq(5)*C(3,j);
    pp{4}(3,j)=Keq(3)*Keq(4)*Keq(5)*C(2,j);
    pp{4}(4,j)=Keq(2)*Keq(3)*Keq(4)*Keq(5)*C(1,j);
end

% Computing total-sum reprenetations of pools
for i=1:n_pool
    for j=1:n_t
        for k=1:i
            pp{i}(i+1,j)=pp{i}(i+1,j)+pp{i}(k,j);
        end
    end
end

%% Plots
hh1=figure;
for i=1:n_met
    plot(t,C(i,:),'-','Color',line_color_met{i},'LineWidth',LW_traj);
    hold on
end
xlabel('$t$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
ylabel('$x$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
xlim([-inf 1e8]);
xticks([1e-2 1e0 1e2 1e4 1e6 1e8]);
set(gca,'XScale','log','XGrid','on','YGrid','on','YMinorGrid','on','MinorGridLineStyle',':');
set(gca,'FontSize',18,'FontName','Times New Roman');
set(gcf,'PaperUnits', 'centimeters');
set(gcf,'PaperSize', [20 16]);
set(gcf,'PaperPosition', [0 0 20 16]);

hh2=figure;
for i=1:n_met
    plot(t,u(i,:),'-','Color',line_color_met{i},'LineWidth',LW_traj);
    hold on
end
xlabel('$t$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
ylabel('$x-x^{\mathrm{ss}}$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
xlim([-inf 1e8]);
xticks([1e-2 1e0 1e2 1e4 1e6 1e8]);
set(gca,'XScale','log','XGrid','on','YGrid','on','YMinorGrid','on','MinorGridLineStyle',':');
set(gca,'FontSize',18,'FontName','Times New Roman');
set(gcf,'PaperUnits', 'centimeters');
set(gcf,'PaperSize', [20 16]);
set(gcf,'PaperPosition', [0 0 20 16]);

hh3=figure;
for i=1:n_rxn
    plot(t,v(i,:),'-','Color',line_color_rxn{i},'LineWidth',LW_traj);
    hold on
end
yline(v_ss,'--k','LineWidth',1);
xlabel('$t$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
ylabel('$v$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
set(gca,'XScale','log','YScale','log','XGrid','on','YGrid','on','YMinorGrid','on','MinorGridLineStyle',':');
set(gca,'FontSize',18,'FontName','Times New Roman');
set(gcf,'PaperUnits', 'centimeters');
set(gcf,'PaperSize', [20 16]);
set(gcf,'PaperPosition', [0 0 20 16]);

hh4=cell(n_pool,1);
for k=1:n_pool
    hh4{k}=figure;
    for i=1:k
        plot(t,pp{k}(i,:),'--','Color',line_color_pool{i},'LineWidth',LW_traj);
        hold on
    end
    plot(t,pp{k}(k+1,:),'-','Color',line_color_sumpool,'LineWidth',LW_traj);
    xlabel('$t$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
    ylabel('$p$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
    xlim([-inf,1e8]);
    xticks([1e-2 1e0 1e2 1e4 1e6 1e8]);
    set(gca,'XScale','log','XGrid','off','YGrid','off','YMinorGrid','off','MinorGridLineStyle',':');
    set(gca,'FontSize',18,'FontName','Times New Roman');
    set(gcf,'PaperUnits', 'centimeters');
    set(gcf,'PaperSize', [20 16]);
    set(gcf,'PaperPosition', [0 0 20 16]);
end

%% Print Plots
print(hh1,'-dpdf',strPlotFilePDF1);
print(hh2,'-dpdf',strPlotFilePDF2);
print(hh3,'-dpdf',strPlotFilePDF3);
for k=1:n_pool
    print(hh4{k},'-dpdf',strPlotFilePDF4{k});
end

return

function dudt=Fun_ode(t,u,J)
    dudt=J*u;
return