function WriteTraj()
clc;

%% Path string parameters
%index=1;

%% Path strings
% Replace WorkingDirectory with your working directory in all the file paths.
strResultsPath='WorkingDirectory\Toy-models\Result-sheets';
strWriteFileEXL=strcat(strResultsPath,'\toy1_traj-',num2str(index),'.xlsx');

%% Parameters
kp=[0.000001;1;0.01;0.0001;0.000001];        % k_PERC
Keq=[1;1;1;1;1];
u0=[0.1;0;0;-0.1];
C_out=[1;0;0;0.1];

T_inf=5e5;
T1=1e-2;
T2=T_inf;

n_tp_inp=300;
r_inp=1.06;

n_met=size(u0,1);

%% Memory allocations
t_inp=zeros(n_tp_inp,1);

%% k_PERC of reverse reactions
kn=kp./Keq;

%% Stoichiometry & G & vv 
S=[1 -1 0 0 0
   0 1 -1 0 0
   0 0 1 -1 0
   0 0 0 1 -1];

G=[-kn(1) 0 0 0
    kp(2) -kn(2) 0 0
    0 kp(3) -kn(3) 0
    0 0 kp(4) -kn(4)
    0 0 0 kp(5)];

vv=[-kp(1)*C_out(1);0;0;0;kn(1)*C_out(4)];

%% Jacobian
J=S*G;

%% Steady state solution
Css=J\S*vv;

%% Solving mass-balance equations
options=odeset('RelTol',1e-8,'AbsTol',1e-10);
sol=ode15s(@(t,u)Fun_ode(t,u,J),[0,1.00000001*T_inf],u0,options);

%% Interpolation setup
dt_inp=(T2-T1)*(1-r_inp)/(1-r_inp^(n_tp_inp-1));
t_inp(1)=T1;
for i=2:n_tp_inp
    t_inp(i)=t_inp(i-1)+r_inp^(i-2)*dt_inp;
end
u_inp=deval(sol,t_inp);

%% Write to Excel sheet
% Sheet 1:
xlSheet=strcat('Time');
xlRange=strcat('B1');
strCell=strcat('t_inp');
writematrix(strCell,strWriteFileEXL,'sheet',xlSheet,'range',xlRange);
for i=1:n_tp_inp
    xlRange=strcat('A',num2str(i+1));
    strCell=strcat('t',num2str(i));
    writematrix(strCell,strWriteFileEXL,'sheet',xlSheet,'range',xlRange);
end
xlRange=strcat('B2:B',num2str(n_tp_inp+1));
writematrix(t_inp,strWriteFileEXL,'sheet',xlSheet,'range',xlRange);

% Sheet 2:
xlSheet=strcat('u_inp');
for i=1:n_met
    xlRange=strcat(xlscol(i+1),'1');
    strCell=strcat('x',num2str(i));
    writematrix(strCell,strWriteFileEXL,'sheet',xlSheet,'range',xlRange);
    xlRange=strcat(xlscol(i+1),'2:',xlscol(i+1),num2str(n_tp_inp+1));
    writematrix(u_inp(i,:)',strWriteFileEXL,'sheet',xlSheet,'range',xlRange);
    
end
for i=1:n_tp_inp
    xlRange=strcat('A',num2str(i+1));
    strCell=strcat('t',num2str(i));
    writematrix(strCell,strWriteFileEXL,'sheet',xlSheet,'range',xlRange);
end

% Sheet 3:
xlSheet=strcat('Css');
for i=1:n_met
    xlRange=strcat(xlscol(i+1),'1');
    strCell=strcat('x',num2str(i));
    writematrix(strCell,strWriteFileEXL,'sheet',xlSheet,'range',xlRange);    
end
xlRange=strcat('A2');
strCell='tss';
writematrix(strCell,strWriteFileEXL,'sheet',xlSheet,'range',xlRange);
xlRange=strcat('B2:',xlscol(n_met+1),'2');
writematrix(Css',strWriteFileEXL,'sheet',xlSheet,'range',xlRange);

return

function dudt=Fun_ode(t,u,J)
    dudt=J*u;
return