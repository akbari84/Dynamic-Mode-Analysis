function PlotTrajTimeGrid()
clc;

%% Path string parameters
index=1;

%% Path strings
% Replace WorkingDirectory with your working directory in all the file paths.
strPlotPath='WorkingDirectory\Toy-models\Plots\Toy1';
strPlotFilePDF=strcat(strPlotPath,'\ConcDeviationProfile_grid-',num2str(index),'.pdf');

%% Parameters
kp=[0.000001;1;0.01;0.0001;0.000001];        % k_PERC
Keq=[1;1;1;1;1];
u0=[0.1;0;0;-0.1];

T_inf=2e7;
T1=1e-4;
T2=T_inf;

n_tp_inp=350;
r_inp=1.075;

n_met=size(u0,1);

%% Memory allocations
t_inp=zeros(n_tp_inp,1);
line_color_met=cell(n_met,1);

%% k_PERC of reverse reactions
kn=kp./Keq;

%% Stoichiometry & G & vv 
S=[1 -1 0 0 0
   0 1 -1 0 0
   0 0 1 -1 0
   0 0 0 1 -1];

G=[-kn(1) 0 0 0
    kp(2) -kn(2) 0 0
    0 kp(3) -kn(3) 0
    0 0 kp(4) -kn(4)
    0 0 0 kp(5)];

%% Jacobian
J=S*G;

%% Solving mass-balance equations
options=odeset('RelTol',1e-8,'AbsTol',1e-8);
sol=ode15s(@(t,u)Fun_ode(t,u,J),[0,1.00000001*T_inf],u0,options);

%% Interpolation setup
dt_inp=(T2-T1)*(1-r_inp)/(1-r_inp^(n_tp_inp-1));
t_inp(1)=T1;
for i=2:n_tp_inp
    t_inp(i)=t_inp(i-1)+r_inp^(i-2)*dt_inp;
end

%% Plot settings
met_first_color=[0, 0, 255]/255;
met_last_color=[255, 0, 0]/255;
met_colormap=customcolormap([0,1],[met_last_color;met_first_color],n_met);

for i=1:n_met
   line_color_met{i}=met_colormap(i,:);
end
LW_traj=2;

%% Plots
hh1=figure;
for i=1:n_met
    plot(sol.x,sol.y(i,:),'-','Color',line_color_met{i},'LineWidth',LW_traj);
    hold on
end
% for i=1:n_tp_inp
%     xline(t_inp(i),'--k');
%     hold on
% end

xlabel('$t$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
ylabel('$x-x^{\mathrm{ss}}$','FontSize',18,'FontName','Times New Roman','Interpreter','latex'); 
set(gca,'XScale','log');
set(gca,'FontSize',18,'FontName','Times New Roman');
set(gcf,'PaperUnits', 'centimeters');
set(gcf,'PaperSize', [20 16]);
set(gcf,'PaperPosition', [0 0 20 16]);

%% Print Plots
print(hh1,'-dpdf',strPlotFilePDF);

return

function dudt=Fun_ode(t,u,J)
    dudt=J*u;
return